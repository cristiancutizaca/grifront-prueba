import { useState, useEffect, useCallback, useRef } from 'react';
import { debounce, serializeFilters, deserializeFilters, filterData } from '@/lib/utils';

export const useFilters = (initialData) => {
  const [filters, setFilters] = useState({
    fechaInicio: '',
    fechaFin: '',
    tipo: 'Todos',
    clientes: [],
    vendedores: [],
    productos: [],
    turnos: []
  });
  
  const [filteredData, setFilteredData] = useState(initialData);
  const [isLoading, setIsLoading] = useState(false);
  const abortControllerRef = useRef(null);

  // Función para cancelar operaciones pendientes
  const cancelPendingOperations = useCallback(() => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
  }, []);

  // Debounced filter function con AbortController
  const debouncedFilter = useCallback(
    debounce((newFilters) => {
      // Cancelar operación anterior si existe
      cancelPendingOperations();
      
      // Crear nuevo AbortController
      abortControllerRef.current = new AbortController();
      const signal = abortControllerRef.current.signal;
      
      setIsLoading(true);
      
      // Simular operación asíncrona que puede ser cancelada
      const filterOperation = new Promise((resolve) => {
        const timeoutId = setTimeout(() => {
          if (!signal.aborted) {
            const filtered = filterData(initialData, newFilters);
            resolve(filtered);
          }
        }, 200);
        
        // Limpiar timeout si se cancela
        signal.addEventListener('abort', () => {
          clearTimeout(timeoutId);
        });
      });
      
      filterOperation.then((filtered) => {
        if (!signal.aborted) {
          setFilteredData(filtered);
          setIsLoading(false);
          
          // Actualizar URL
          const queryString = serializeFilters(newFilters);
          const newUrl = queryString ? `${window.location.pathname}?${queryString}` : window.location.pathname;
          window.history.replaceState({}, '', newUrl);
        }
      }).catch(() => {
        // Operación cancelada o error
        if (!signal.aborted) {
          setIsLoading(false);
        }
      });
    }, 400),
    [initialData, cancelPendingOperations]
  );

  // Efecto para aplicar filtros con debounce
  useEffect(() => {
    debouncedFilter(filters);
    
    // Cleanup al desmontar
    return () => {
      cancelPendingOperations();
    };
  }, [filters, debouncedFilter, cancelPendingOperations]);

  // Cargar filtros desde URL al montar
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.toString()) {
      const urlFilters = deserializeFilters(urlParams);
      setFilters(prev => ({ ...prev, ...urlFilters }));
    }
  }, []);

  // Handlers para filtros
  const handleFilterChange = useCallback((key, value) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  }, []);

  const clearAllFilters = useCallback(() => {
    cancelPendingOperations();
    setFilters({
      fechaInicio: '',
      fechaFin: '',
      tipo: 'Todos',
      clientes: [],
      vendedores: [],
      productos: [],
      turnos: []
    });
  }, [cancelPendingOperations]);

  return {
    filters,
    filteredData,
    isLoading,
    handleFilterChange,
    clearAllFilters
  };
};


import React, { useState } from 'react';
import { Download, FileSpreadsheet, FileText, TrendingUp, TrendingDown, DollarSign } from 'lucide-react';
import MultiSelectCombobox from './MultiSelectCombobox';
import { useFilters } from './hooks/useFilters';
import { 
  DATOS_REPORTE, 
  OPCIONES_CLIENTES, 
  OPCIONES_VENDEDORES, 
  OPCIONES_PRODUCTOS, 
  OPCIONES_TURNOS,
  TIPOS_MOVIMIENTO,
  BADGE_STYLES 
} from './lib/types';
import { 
  formatPEN, 
  calculateKPIs, 
  paginateData,
  cn 
} from './lib/utils';
import { exportToCSV, exportToPDF } from './lib/export';

const GrifoReportes = () => {
  // Estados
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize] = useState(10);

  // Hook personalizado para filtros
  const { filters, filteredData, isLoading, handleFilterChange, clearAllFilters } = useFilters(DATOS_REPORTE);

  // Reset página cuando cambian los datos filtrados
  React.useEffect(() => {
    setCurrentPage(1);
  }, [filteredData]);

  // Cálculos
  const kpis = calculateKPIs(filteredData);
  const paginatedResult = paginateData(filteredData, currentPage, pageSize);

  // Export functions
  const handleExportExcel = () => {
    const timestamp = new Date().toISOString().slice(0, 10);
    const filename = `reporte-grifo-${timestamp}`;
    exportToCSV(filteredData, filename);
  };

  const handleExportPDF = () => {
    exportToPDF(filteredData, kpis, filters);
  };

  return (
    <main className="p-4 md:p-8 w-full min-h-screen bg-gray-900">
      {/* Header */}
      <header className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
        <h1 className="text-3xl font-bold text-gray-100 mb-4 md:mb-0">Reportes Generales</h1>
        <div className="flex gap-2">
          <button 
            onClick={handleExportPDF}
            className="flex items-center bg-red-600 hover:bg-red-700 text-white font-medium py-2 px-4 rounded-lg transition duration-200 focus:ring-2 focus:ring-red-500 focus:outline-none"
            aria-label="Exportar datos filtrados a PDF"
          >
            <FileText className="h-4 w-4 mr-2" />
            PDF
          </button>
          <button 
            onClick={handleExportExcel}
            className="flex items-center bg-green-600 hover:bg-green-700 text-white font-medium py-2 px-4 rounded-lg transition duration-200 focus:ring-2 focus:ring-green-500 focus:outline-none"
            aria-label="Exportar datos filtrados a Excel"
          >
            <FileSpreadsheet className="h-4 w-4 mr-2" />
            Excel
          </button>
        </div>
      </header>

      {/* Filtros */}
      <section className="bg-gray-800 p-4 rounded-lg mb-6 shadow-lg">
        {/* Primera fila de filtros */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
          <div>
            <label className="block text-sm text-gray-400 mb-1">Fecha Inicio</label>
            <input
              type="date"
              value={filters.fechaInicio}
              onChange={(e) => handleFilterChange('fechaInicio', e.target.value)}
              className="w-full bg-gray-700 text-gray-200 border border-gray-600 rounded-md p-2 focus:ring-2 focus:ring-orange-500 focus:border-orange-500 focus:outline-none"
              aria-label="Fecha de inicio del filtro"
            />
          </div>
          <div>
            <label className="block text-sm text-gray-400 mb-1">Fecha Fin</label>
            <input
              type="date"
              value={filters.fechaFin}
              onChange={(e) => handleFilterChange('fechaFin', e.target.value)}
              className="w-full bg-gray-700 text-gray-200 border border-gray-600 rounded-md p-2 focus:ring-2 focus:ring-orange-500 focus:border-orange-500 focus:outline-none"
              aria-label="Fecha de fin del filtro"
            />
          </div>
          <div>
            <label className="block text-sm text-gray-400 mb-1">Tipo de Operación</label>
            <select 
              value={filters.tipo}
              onChange={(e) => handleFilterChange('tipo', e.target.value)}
              className="w-full bg-gray-700 text-gray-200 border border-gray-600 rounded-md p-2 focus:ring-2 focus:ring-orange-500 focus:border-orange-500 focus:outline-none"
              aria-label="Tipo de operación"
            >
              <option value="Todos">Todos</option>
              <option value={TIPOS_MOVIMIENTO.VENTA}>Venta</option>
              <option value={TIPOS_MOVIMIENTO.COMPRA}>Compra</option>
              <option value={TIPOS_MOVIMIENTO.GASTO}>Gasto</option>
            </select>
          </div>
          <div className="flex items-end">
            <button 
              onClick={clearAllFilters}
              className="w-full bg-gray-600 hover:bg-gray-700 text-white font-medium py-2 px-4 rounded-lg transition duration-200 focus:ring-2 focus:ring-gray-500 focus:outline-none"
              aria-label="Limpiar todos los filtros"
            >
              Limpiar Filtros
            </button>
          </div>
        </div>

        {/* Segunda fila de filtros - Comboboxes mejorados */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <MultiSelectCombobox
            label="Cliente"
            options={OPCIONES_CLIENTES}
            value={filters.clientes}
            onChange={(value) => handleFilterChange('clientes', value)}
            placeholder="Seleccionar clientes..."
          />
          <MultiSelectCombobox
            label="Vendedor"
            options={OPCIONES_VENDEDORES}
            value={filters.vendedores}
            onChange={(value) => handleFilterChange('vendedores', value)}
            placeholder="Seleccionar vendedores..."
          />
          <MultiSelectCombobox
            label="Producto"
            options={OPCIONES_PRODUCTOS}
            value={filters.productos}
            onChange={(value) => handleFilterChange('productos', value)}
            placeholder="Seleccionar productos..."
          />
          <MultiSelectCombobox
            label="Turno"
            options={OPCIONES_TURNOS}
            value={filters.turnos}
            onChange={(value) => handleFilterChange('turnos', value)}
            placeholder="Seleccionar turnos..."
          />
        </div>
      </section>

      {/* Resumen de filtros activos */}
      {(filters.fechaInicio || filters.fechaFin || filters.tipo !== 'Todos' || 
        filters.clientes.length > 0 || filters.vendedores.length > 0 || 
        filters.productos.length > 0 || filters.turnos.length > 0) && (
        <section className="bg-gray-800 p-3 rounded-lg mb-6 border-l-4 border-orange-500">
          <div className="flex flex-wrap items-center gap-2 text-sm">
            <span className="text-gray-300 font-medium">Filtros activos:</span>
            <span className="text-gray-400">{filteredData.length} de {DATOS_REPORTE.length} registros</span>
            {filters.fechaInicio && (
              <span className="px-2 py-1 bg-blue-900/40 text-blue-300 rounded text-xs">
                Desde: {filters.fechaInicio}
              </span>
            )}
            {filters.fechaFin && (
              <span className="px-2 py-1 bg-blue-900/40 text-blue-300 rounded text-xs">
                Hasta: {filters.fechaFin}
              </span>
            )}
            {filters.tipo !== 'Todos' && (
              <span className="px-2 py-1 bg-purple-900/40 text-purple-300 rounded text-xs">
                Tipo: {filters.tipo}
              </span>
            )}
          </div>
        </section>
      )}

      {/* KPIs */}
      <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
        {/* Ingresos */}
        <div className="bg-gray-800 p-6 rounded-lg shadow-lg text-white flex justify-between items-center">
          <div>
            <p className="text-sm text-gray-400 uppercase font-medium">Ingresos Totales</p>
            <p className="text-3xl font-bold tabular-nums">{formatPEN(kpis.totalIngresos)}</p>
          </div>
          <div className="bg-green-500/20 p-3 rounded-full">
            <TrendingUp className="h-8 w-8 text-green-400" />
          </div>
        </div>

        {/* Egresos */}
        <div className="bg-gray-800 p-6 rounded-lg shadow-lg text-white flex justify-between items-center">
          <div>
            <p className="text-sm text-gray-400 uppercase font-medium">Egresos Totales</p>
            <p className="text-3xl font-bold tabular-nums">{formatPEN(kpis.totalEgresos)}</p>
          </div>
          <div className="bg-red-500/20 p-3 rounded-full">
            <TrendingDown className="h-8 w-8 text-red-400" />
          </div>
        </div>

        {/* Balance */}
        <div className="bg-gray-800 p-6 rounded-lg shadow-lg text-white flex justify-between items-center">
          <div>
            <p className="text-sm text-gray-400 uppercase font-medium">Balance</p>
            <p className={cn(
              "text-3xl font-bold tabular-nums",
              kpis.balance >= 0 ? "text-green-400" : "text-red-400"
            )}>
              {formatPEN(kpis.balance)}
            </p>
          </div>
          <div className={cn(
            "p-3 rounded-full",
            kpis.balance >= 0 ? "bg-green-500/20" : "bg-red-500/20"
          )}>
            <DollarSign className={cn(
              "h-8 w-8",
              kpis.balance >= 0 ? "text-green-400" : "text-red-400"
            )} />
          </div>
        </div>
      </section>

      {/* Tabla */}
      <section className="bg-gray-800 rounded-lg shadow-lg overflow-hidden">
        {isLoading ? (
          <div className="p-8 text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-orange-500 mx-auto"></div>
            <p className="text-gray-400 mt-2">Cargando datos...</p>
          </div>
        ) : filteredData.length === 0 ? (
          <div className="p-8 text-center">
            <p className="text-gray-400">No se encontraron datos con los filtros aplicados</p>
          </div>
        ) : (
          <>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-gray-300">
                <thead className="bg-gray-700 sticky top-0">
                  <tr>
                    <th scope="col" className="p-4 text-sm text-gray-300 font-medium">Fecha</th>
                    <th scope="col" className="p-4 text-sm text-gray-300 font-medium">Tipo</th>
                    <th scope="col" className="p-4 text-sm text-gray-300 font-medium">Producto</th>
                    <th scope="col" className="p-4 text-sm text-gray-300 font-medium text-right">Cantidad</th>
                    <th scope="col" className="p-4 text-sm text-gray-300 font-medium text-right">Monto</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-700">
                  {paginatedResult.data.map((item, i) => (
                    <tr 
                      key={item.id} 
                      className={cn(
                        "hover:bg-gray-700 transition-colors",
                        i % 2 === 0 ? "bg-gray-800" : "bg-gray-800/50"
                      )}
                    >
                      <td className="p-4">{item.fecha}</td>
                      <td className="p-4">
                        <span className={cn(
                          "px-2 py-1 rounded-full text-xs font-medium",
                          BADGE_STYLES[item.tipo]
                        )}>
                          {item.tipo}
                        </span>
                      </td>
                      <td className="p-4">{item.producto}</td>
                      <td className="p-4 text-right tabular-nums">
                        {item.cantidad} {item.unidad}
                      </td>
                      <td className={cn(
                        "p-4 text-right font-semibold tabular-nums",
                        item.tipo === TIPOS_MOVIMIENTO.VENTA ? "text-green-400" : "text-red-400"
                      )}>
                        {item.tipo === TIPOS_MOVIMIENTO.VENTA ? '+' : '-'} {formatPEN(item.monto)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Paginación */}
            <div className="p-4 bg-gray-700 flex justify-between items-center">
              <span className="text-sm text-gray-400">
                Mostrando {((currentPage - 1) * pageSize) + 1} a {Math.min(currentPage * pageSize, paginatedResult.totalItems)} de {paginatedResult.totalItems} resultados
              </span>
              <div className="flex space-x-1">
                <button
                  onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                  disabled={!paginatedResult.hasPrevPage}
                  className={cn(
                    "px-3 py-1 border rounded-md text-sm transition-colors focus:ring-2 focus:outline-none",
                    paginatedResult.hasPrevPage
                      ? "border-orange-500 text-orange-400 hover:bg-orange-500/10 focus:ring-orange-500"
                      : "border-gray-600 text-gray-500 cursor-not-allowed"
                  )}
                  aria-label="Ir a la página anterior"
                >
                  Anterior
                </button>
                <span className="px-3 py-1 border border-orange-500 bg-orange-500 rounded-md text-sm text-white">
                  {currentPage}
                </span>
                <button
                  onClick={() => setCurrentPage(prev => Math.min(prev + 1, paginatedResult.totalPages))}
                  disabled={!paginatedResult.hasNextPage}
                  className={cn(
                    "px-3 py-1 border rounded-md text-sm transition-colors focus:ring-2 focus:outline-none",
                    paginatedResult.hasNextPage
                      ? "border-orange-500 text-orange-400 hover:bg-orange-500/10 focus:ring-orange-500"
                      : "border-gray-600 text-gray-500 cursor-not-allowed"
                  )}
                  aria-label="Ir a la página siguiente"
                >
                  Siguiente
                </button>
              </div>
            </div>
          </>
        )}
      </section>
    </main>
  );
};

export default GrifoReportes;


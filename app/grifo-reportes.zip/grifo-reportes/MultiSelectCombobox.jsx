import React, { useState, useRef, useEffect } from 'react';
import { Check, ChevronDown, X } from 'lucide-react';
import { cn } from '@/lib/utils';

const MultiSelectCombobox = ({ 
  options = [], 
  value = [], 
  onChange, 
  placeholder = "Seleccionar...",
  label,
  className 
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const containerRef = useRef(null);
  const inputRef = useRef(null);

  const filteredOptions = options.filter(option =>
    option.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleToggle = (option) => {
    const newValue = value.includes(option)
      ? value.filter(v => v !== option)
      : [...value, option];
    onChange(newValue);
  };

  const handleRemoveChip = (option, e) => {
    e.stopPropagation();
    const newValue = value.filter(v => v !== option);
    onChange(newValue);
  };

  const handleClearAll = () => {
    onChange([]);
  };

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (containerRef.current && !containerRef.current.contains(event.target)) {
        setIsOpen(false);
        setSearchTerm('');
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div className={cn("relative", className)} ref={containerRef}>
      {label && (
        <label className="block text-sm text-gray-400 mb-1">{label}</label>
      )}
      
      <div
        className={cn(
          "min-h-[2.5rem] w-full bg-gray-700 text-gray-200 border border-gray-600 rounded-md p-2 cursor-pointer",
          "focus-within:ring-2 focus-within:ring-orange-500 focus-within:border-orange-500",
          isOpen && "ring-2 ring-orange-500 border-orange-500"
        )}
        onClick={() => {
          setIsOpen(!isOpen);
          if (!isOpen) {
            setTimeout(() => inputRef.current?.focus(), 0);
          }
        }}
      >
        <div className="flex flex-wrap gap-1 items-center">
          {value.length > 0 ? (
            value.map((item) => (
              <span
                key={item}
                className="inline-flex items-center gap-1 px-2 py-1 bg-orange-500/20 text-orange-300 text-xs rounded-md"
              >
                {item}
                <button
                  onClick={(e) => handleRemoveChip(item, e)}
                  className="hover:bg-orange-500/30 rounded-sm p-0.5"
                  aria-label={`Remover ${item}`}
                >
                  <X className="h-3 w-3" />
                </button>
              </span>
            ))
          ) : (
            <span className="text-gray-400 text-sm">{placeholder}</span>
          )}
          
          <div className="flex-1 min-w-[100px]">
            <input
              ref={inputRef}
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-transparent border-none outline-none text-sm text-gray-200 placeholder-gray-400"
              placeholder={isOpen ? "Buscar..." : ""}
            />
          </div>
          
          <div className="flex items-center gap-1 ml-2">
            {value.length > 0 && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  handleClearAll();
                }}
                className="hover:bg-gray-600 rounded-sm p-1"
                aria-label="Limpiar selección"
              >
                <X className="h-4 w-4 text-gray-400" />
              </button>
            )}
            <ChevronDown 
              className={cn(
                "h-4 w-4 text-gray-400 transition-transform",
                isOpen && "rotate-180"
              )} 
            />
          </div>
        </div>
      </div>

      {isOpen && (
        <div className="absolute z-50 w-full mt-1 bg-gray-700 border border-gray-600 rounded-md shadow-lg max-h-60 overflow-auto">
          {filteredOptions.length > 0 ? (
            filteredOptions.map((option) => (
              <div
                key={option}
                className={cn(
                  "flex items-center justify-between px-3 py-2 cursor-pointer hover:bg-gray-600 text-sm",
                  value.includes(option) && "bg-orange-500/20"
                )}
                onClick={() => handleToggle(option)}
              >
                <span className="text-gray-200">{option}</span>
                {value.includes(option) && (
                  <Check className="h-4 w-4 text-orange-400" />
                )}
              </div>
            ))
          ) : (
            <div className="px-3 py-2 text-sm text-gray-400">
              No se encontraron opciones
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default MultiSelectCombobox;

